MadCap.Utilities.Xhr._FilePathToXmlStringMap.Add(
	'Toc',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<CatapultToc Version=\"1\" DescendantCount=\"22\">' +
	'    <!-- saved from url=(0014)about:internet -->' +
	'    <TocEntry Title=\"Honeywell Printing SDK for Apple iOS Developer Guide\" Link=\"/Content/HoneywellPrintingSDKforAppleiOSDeveloperGuide.htm\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"true\" DescendantCount=\"3\">' +
	'        <TocEntry Title=\"How to Use the SDK\" Link=\"/Content/HowtoUsetheSDK.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Set Up the Xcode Environment\" Link=\"/Content/SetUptheXcodeEnvironment.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Initialize the SDK\" Link=\"/Content/InitializetheSDK.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"How to Print a Report\" Link=\"/Content/HowtoPrintaReport.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"7\">' +
	'        <TocEntry Title=\"About the ITCLinePrinter Init\" Link=\"/Content/AbouttheITCLinePrinterInit.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Register an Event Listener\" Link=\"/Content/RegisteranEventListener.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Connect to a Printer\" Link=\"/Content/ConnecttoaPrinter.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Change the Font Style\" Link=\"/Content/ChangetheFontStyle.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Write Text to the Printer and Position the Printhead\" Link=\"/Content/WriteTexttothePrinterandPositionthePrinthead.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Print Bitmap Files\" Link=\"/Content/PrintBitmapFiles.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Disconnect from the Printer and Release Resources\" Link=\"/Content/DisconnectfromthePrinterandReleaseResources.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"About the ITCLinePrinter Events\" Link=\"/Content/AbouttheITCLinePrinterEvents.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    <TocEntry Title=\"ITCLinePrinterException Error Codes\" Link=\"/Content/ITCLinePrinterExceptionErrorCodes.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    <TocEntry Title=\"About the Commands and Attributes File\" Link=\"/Content/AbouttheCommandsandAttributesFile.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"5\">' +
	'        <TocEntry Title=\"About INCLUDE\" Link=\"/Content/AboutINCLUDE.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"2\">' +
	'            <TocEntry Title=\"How to Use Multiple INCLUDE Items\" Link=\"/Content/HowtoUseMultipleINCLUDEItems.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"How to Use INCLUDE Recursively\" Link=\"/Content/HowtoUseINCLUDERecursively.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"About Precedence\" Link=\"/Content/AboutPrecedence.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"About Reserved Name Value Pairs\" Link=\"/Content/AboutReservedNameValuePairs.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Use Easy Print Mode\" Link=\"/Content/UseEasyPrintMode.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    <TocEntry Title=\"Contact Support\" Link=\"/Content/ContactSupport.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'</CatapultToc>'
);
