MadCap.Utilities.Xhr._FilePathToXmlStringMap.Add(
	'HelpSystem',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<WebHelpSystem DefaultUrl=\"Content/HoneywellPrintingSDKforAppleiOSDeveloperGuide.htm\" Toc=\"Data/Toc.xml\" Index=\"Data/Index.xml\" Concepts=\"Data/Concepts.xml\" Glossary=\"Data/Glossary.xml\" SearchDatabase=\"Data/Search.xml\" Alias=\"Data/Alias.xml\" Synonyms=\"Data/Synonyms.xml\" SearchFilterSet=\"Data/Filters.xml\" SkinName=\"Honeywell\" Skins=\"Honeywell,HTML5,Intermec\" BuildTime=\"7/13/2015 1:31:47 PM\" BuildVersion=\"8.1.2.0\" TargetType=\"WebHelp2\" SkinTemplateFolder=\"Skin/\" InPreviewMode=\"false\" MoveOutputContentToRoot=\"false\" MakeFileLowerCase=\"false\" UseCustomTopicFileExtension=\"false\">' +
	'    <!-- saved from url=(0014)about:internet -->' +
	'    <CatapultSkin Version=\"2\" SkinType=\"WebHelp2\" Comment=\"HTML5 skin\" Anchors=\"Width,Height\" Width=\"800\" Height=\"600\" Top=\"0\" Left=\"0\" Bottom=\"0\" Right=\"0\" Tabs=\"TOC\" DefaultTab=\"TOC\" UseBrowserDefaultSize=\"True\" UseDefaultBrowserSetup=\"true\" AutoSyncTOC=\"true\" CommentsInTopic=\"false\" BrowserSetup=\"Menu\" Name=\"Honeywell\">' +
	'        <Toolbar EnableCustomLayout=\"true\" Buttons=\"Print\">' +
	'            <Script>$(document).ready(function(){' +
	'   $(\"div#header&gt;a\").attr({href: \"http://www.honeywellaidc.com/\", target:\"_blank\" });   ' +
	'});</Script>' +
	'        </Toolbar>' +
	'    </CatapultSkin>' +
	'    <CatapultSkin Version=\"1\" SkinType=\"WebHelp2\" Comment=\"HTML5 skin\" Anchors=\"Width,Height\" Width=\"800\" Height=\"600\" Top=\"0\" Left=\"0\" Bottom=\"0\" Right=\"0\" Tabs=\"TOC\" DefaultTab=\"TOC\" UseBrowserDefaultSize=\"True\" UseDefaultBrowserSetup=\"false\" BrowserSetup=\"Resizable\" NavigationLinkTop=\"true\" AutoSyncTOC=\"true\" Name=\"HTML5\">' +
	'        <Toolbar EnableCustomLayout=\"true\" Buttons=\"Print|NextTopic|PreviousTopic|ExpandAll\">' +
	'            <Script>$(document).ready(function(){' +
	'   $(\"div#header&gt;a\").attr({href: \"http://www.honeywellaidc.com/\", target:\"_blank\" });   ' +
	'});</Script>' +
	'        </Toolbar>' +
	'    </CatapultSkin>' +
	'    <CatapultSkin Version=\"2\" SkinType=\"WebHelp2\" Comment=\"HTML5 skin\" Anchors=\"Width,Height\" Width=\"800\" Height=\"600\" Top=\"0\" Left=\"0\" Bottom=\"0\" Right=\"0\" Tabs=\"TOC\" DefaultTab=\"TOC\" UseBrowserDefaultSize=\"True\" UseDefaultBrowserSetup=\"True\" AutoSyncTOC=\"true\" Name=\"Intermec\">' +
	'        <Toolbar EnableCustomLayout=\"true\" Buttons=\"Print\">' +
	'            <Script>$(document).ready(function(){' +
	'   $(\"div#header&gt;a\").attr(\"href\", \"http://www.intermec.com/\");' +
	'});</Script>' +
	'        </Toolbar>' +
	'    </CatapultSkin>' +
	'</WebHelpSystem>'
);
