MadCap.Utilities.Xhr._FilePathToXmlStringMap.Add(
	'Toc',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<CatapultToc Version=\"1\" DescendantCount=\"45\">' +
	'    <!-- saved from url=(0014)about:internet -->' +
	'    <TocEntry Title=\"Honeywell Printing SDK for Apple iOS API Reference\" Link=\"/Content/HoneywellPrintingSDKforAppleiOSAPIReference.htm\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"true\" DescendantCount=\"0\" />' +
	'    <TocEntry Title=\"API Reference\" Link=\"/Content/APIReference.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"42\">' +
	'        <TocEntry Title=\"ITCLinePrinter Class\" Link=\"/Content/ITCLinePrinterClass.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"27\">' +
	'            <TocEntry Title=\"init Method\" Link=\"/Content/initMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"addPrintProgressListener Method\" Link=\"/Content/addPrintProgressListenerMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"clearMSR Method\" Link=\"/Content/clearMSRMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"close Method\" Link=\"/Content/closeMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"connect Method\" Link=\"/Content/connectMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"disconnect Method\" Link=\"/Content/disconnectMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"endDoc Method\" Link=\"/Content/endDocMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"flush Method\" Link=\"/Content/flushMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"formFeed Method\" Link=\"/Content/formFeedMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"getBytesWritten Method\" Link=\"/Content/getBytesWrittenMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"readMSR Method\" Link=\"/Content/readMSRMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"removePrintProgressListener Method\" Link=\"/Content/removePrintProgressListenerMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"sendCustomCommand Method\" Link=\"/Content/sendCustomCommandMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"setBold Method\" Link=\"/Content/setBoldMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"setCompress Method\" Link=\"/Content/setCompressMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"setDoubleHigh Method\" Link=\"/Content/setDoubleHighMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"setDoubleWide Method\" Link=\"/Content/setDoubleWideMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"setSettingBool Method\" Link=\"/Content/setSettingBoolMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"setSettingBytes Method\" Link=\"/Content/setSettingBytesMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"setSettingNum Method\" Link=\"/Content/setSettingNumMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"setSettingString Method\" Link=\"/Content/setSettingStringMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"write Method\" Link=\"/Content/writeMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"writeBarcode Method\" Link=\"/Content/writeBarcodeMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"writeGraphic Method\" Link=\"/Content/writeGraphicMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"writeGraphicBase64 Method\" Link=\"/Content/writeGraphicBase64Method.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"writeLine Method\" Link=\"/Content/writeLineMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"newLine Method\" Link=\"/Content/newLineMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"ITCExtraSettings Class\" Link=\"/Content/ITCExtraSettingsClass.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"5\">' +
	'            <TocEntry Title=\"retrieveExtraSettings Method\" Link=\"/Content/retrieveExtraSettingsMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"setAccessory Method\" Link=\"/Content/setAccessoryMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"getAccessory Method\" Link=\"/Content/getAccessoryMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"setProtocolString Method\" Link=\"/Content/setProtocolStringMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"getProtocolString Method\" Link=\"/Content/getProtocolStringMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"ITCLinePrinterException Class\" Link=\"/Content/ITCLinePrinterExceptionClass.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"2\">' +
	'            <TocEntry Title=\"initWithError Method\" Link=\"/Content/initWithErrorMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"getErrorCode Method\" Link=\"/Content/getErrorCodeMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"ITCPrintProgressEvent Class\" Link=\"/Content/ITCPrintProgressEventClass.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"1\">' +
	'            <TocEntry Title=\"getMessageType Method\" Link=\"/Content/getMessageTypeMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"ITCPrintProgressListener Class\" Link=\"/Content/ITCPrintProgressListenerClass.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"2\">' +
	'            <TocEntry Title=\"ITCPrintProgressDelegate Protocol\" Link=\"/Content/ITCPrintProgressDelegateProtocol.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"receivedStatus Method\" Link=\"/Content/receivedStatusMethod.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Contact Support\" Link=\"/Content/Contact Support.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'</CatapultToc>'
);
