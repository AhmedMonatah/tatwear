MadCap.Utilities.Xhr._FilePathToXmlStringMap.Add(
	'Synonyms',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<MadCapSynonyms>' +
	'    <!-- saved from url=(0014)about:internet -->' +
	'    <Groups />' +
	'    <Directional />' +
	'</MadCapSynonyms>'
);
