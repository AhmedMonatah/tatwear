MadCap.Utilities.Xhr._FilePathToXmlStringMap.Add(
	'Filters',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<CatapultSearchFilterSet>' +
	'    <!-- saved from url=(0014)about:internet -->' +
	'    <SearchFilter Name=\"My Subset\">' +
	'    </SearchFilter>' +
	'</CatapultSearchFilterSet>'
);
